"""Run the Linux file-backed comparison defined in README.md."""

import argparse
import hashlib
import json
import os
import platform
import re
import shutil
import subprocess
import tempfile
from pathlib import Path
from statistics import median

HERE = Path(__file__).resolve().parent
MIB = 1 << 20
BLOCK = 64 << 10
MEMBER = 3589358312608496142804550037657486194871
OUTSIDER = 1540147111665682694523005535063805113443
OUTSIDER_REMAINDER = 833120395990529729763735569905656999601
ROW_HASH = "348ebfcdcdc233c347a59581db14ace6c611eb0fd9eb1d1fb82c16d1a29e9820"
BINARY_HASH = "b4a6c3bb41f08ef79c63ab6cbc0dcaa65db2405c6ace6819859366ec80021c5b"


def sha256(path):
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


def warm(path):
    with path.open("rb") as stream:
        buf = bytearray(MIB)
        while stream.readinto(buf):
            pass


def from_checkpoint(source, destination):
    """Import the archived ASCII NAF row eight positions at a time."""
    if sha256(source) != ROW_HASH:
        raise ValueError("unexpected 30,000-prime canonical row hash")
    total = bit = 0
    with source.open("rb") as src, destination.open("wb") as dest:
        while block := src.read(BLOCK):
            out = bytearray()
            for digit in block:
                if digit != 48:
                    total += (1 if digit == 43 else -1) << bit
                bit += 1
                if bit == 8:
                    out.append(total & 255)
                    total >>= 8
                    bit = 0
            dest.write(out)
        if bit:
            dest.write(bytes([total]))
    assert sha256(destination) == BINARY_HASH


def generate_cofactor(path, size):
    with path.open("wb") as stream:
        for offset in range(0, size, MIB):
            count = min(MIB, size - offset)
            seed = f"prime-numbers/packed-scale/v1/{size}/{offset}".encode()
            block = bytearray(hashlib.shake_256(seed).digest(count))
            if offset == 0:
                block[0] |= 1
            if offset + count == size:
                block[-1] |= 128
            stream.write(block)


def reference_grant(source, target):
    carry = 0
    with source.open("rb") as src, target.open("wb") as dest:
        while block := src.read(BLOCK):
            bits = 8 * len(block)
            value = int.from_bytes(block, "little") * MEMBER + carry
            dest.write((value & ((1 << bits) - 1)).to_bytes(len(block), "little"))
            carry = value >> bits
        dest.write(carry.to_bytes((carry.bit_length() + 7) // 8, "little"))


def reference_division(source, divisor, target=None):
    """Independent descending block division. Only the small remainder is retained."""
    remainder = 0
    with source.open("rb") as src:
        pos = src.seek(0, os.SEEK_END)
        out = target.open("wb") if target else None
        try:
            leading = True
            while pos:
                n = min(pos, BLOCK)
                pos -= n
                src.seek(pos)
                value = (remainder << (8 * n)) + int.from_bytes(src.read(n), "little")
                if out is None:
                    remainder = value % divisor
                else:
                    q, remainder = divmod(value, divisor)
                    digits = q.to_bytes(n, "little")
                    if leading:
                        digits = digits.rstrip(b"\x00")
                        leading = not digits
                    if digits:
                        out.seek(pos)
                        out.write(digits)
        finally:
            if out:
                out.close()
    return remainder


def invoke(worker, *args, expected=0):
    result = subprocess.run([*worker, *map(str, args)], capture_output=True, text=True)
    if result.returncode != expected:
        raise RuntimeError(f"{args}: exit {result.returncode}: {result.stderr}")
    return result


def toy_checks(worker, folder):
    b, n = folder / "small.bin", folder / "small.naf"
    out, check = folder / "small.out", folder / "small.check"
    # GMP blocks are 64 KiB. Constructing a scalar here is limited to these toy cases.
    values = [0, 1, 2, 3, 7, 23, 255, 256, 257]
    for exponent in [63, 64, 65, 8 * BLOCK - 1, 8 * BLOCK, 8 * BLOCK + 1]:
        values.extend([(1 << exponent) - 1, (1 << exponent) + 1])
    for x in values:
        b.write_bytes(x.to_bytes((x.bit_length() + 7) // 8, "little"))
        invoke(worker, "convert", "bin-to-naf", b, n)
        invoke(worker, "convert", "naf-to-bin", n, check)
        assert check.read_bytes() == b.read_bytes()
        for fmt, src in [("binary", b), ("naf", n)]:
            assert int(invoke(worker, fmt, "mod", src, MEMBER).stdout) == x % MEMBER
            invoke(worker, fmt, "mul", src, MEMBER, out)
            if fmt == "naf":
                invoke(worker, "convert", "naf-to-bin", out, check)
            assert int.from_bytes((check if fmt == "naf" else out).read_bytes(), "little") == x * MEMBER
            invoke(worker, fmt, "div", out, MEMBER, check)
            assert check.read_bytes() == src.read_bytes()
            if x % MEMBER:
                check.write_bytes(b"previous destination")
                invoke(worker, fmt, "div", src, MEMBER, check, expected=3)
                assert check.read_bytes() == b"previous destination"
    return len(values)


def timed(worker, fmt, op, source, output):
    warm(source)
    args = [fmt, op, source, MEMBER]
    if op != "mod":
        output.unlink(missing_ok=True)
        args.append(output)
    result = invoke(worker, *args)
    if op == "mod":
        assert int(result.stdout) == 0
    m = re.search(r"seconds=([\d.]+)\s+peak_rss_kib=(\d+)", result.stderr)
    if not m:
        raise RuntimeError("missing worker instrumentation: " + result.stderr)
    return float(m[1]), int(m[2])


def run_case(worker, folder, size, checkpoint, repeats):
    base = folder / "cofactor.bin"
    label = folder / "label.bin"
    if checkpoint:
        from_checkpoint(checkpoint, label)
        assert reference_division(label, MEMBER, base) == 0
    else:
        generate_cofactor(base, size)
        reference_grant(base, label)
    outsider = reference_division(base, OUTSIDER) * MEMBER % OUTSIDER
    assert outsider and reference_division(base, MEMBER) != 0
    if checkpoint:
        assert outsider == OUTSIDER_REMAINDER
    operands = {"binary": (base, label), "naf": (folder / "cofactor.naf", folder / "label.naf")}
    for src, dest in zip(operands["binary"], operands["naf"]):
        invoke(worker, "convert", "bin-to-naf", src, dest)
    rows = {}
    for fmt, (q, p) in operands.items():
        assert int(invoke(worker, fmt, "mod", p, OUTSIDER).stdout) == outsider
        assert int(invoke(worker, fmt, "mod", q, MEMBER).stdout) != 0
        rows[fmt] = {"label_bytes": p.stat().st_size, "cofactor_bytes": q.stat().st_size,
                     "label_sha256": sha256(p), "cofactor_sha256": sha256(q), "operations": {}}
    output = folder / "updated"
    for operation in ["mod", "div", "mul"]:
        samples = {fmt: [] for fmt in operands}
        for repetition in range(repeats):
            for fmt in list(operands)[::1 if repetition % 2 == 0 else -1]:
                q, p = operands[fmt]
                source = q if operation == "mul" else p
                samples[fmt].append(timed(worker, fmt, operation, source, output))
                if operation != "mod":
                    expected = "cofactor_sha256" if operation == "div" else "label_sha256"
                    assert sha256(output) == rows[fmt][expected]
        for fmt, values in samples.items():
            elapsed = [entry[0] for entry in values]
            rows[fmt]["operations"][operation] = {
                "seconds": elapsed, "median_seconds": median(elapsed),
                "max_peak_rss_kib": max(entry[1] for entry in values)}
        print(f"  {operation}: " + ", ".join(
            f"{fmt} {rows[fmt]['operations'][operation]['median_seconds']:.5f}s" for fmt in rows
        ), flush=True)
    return {"input": "30000-prime checkpoint" if checkpoint else "synthetic dense cofactor",
            "outsider_remainder": str(outsider), "repeats": repeats, "formats": rows}


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--checkpoint-row", type=Path, help="archived 30000.row, see README")
    ap.add_argument("--sizes-mib", type=int, nargs="*", default=[8, 128, 1024, 2048])
    ap.add_argument("--repeats", type=int, default=3)
    ap.add_argument("--scratch", type=Path, help="directory for temporary files")
    ap.add_argument("--output", type=Path, required=True)
    args = ap.parse_args()
    if args.repeats < 1 or any(size < 1 for size in args.sizes_mib):
        ap.error("sizes and repetition count must be positive")
    if not __debug__:
        ap.error("run with Python assertions enabled")
    case_sizes = ([None] if args.checkpoint_row else []) + args.sizes_mib
    pinned = min(os.sched_getaffinity(0))
    os.sched_setaffinity(0, {pinned})
    with tempfile.TemporaryDirectory(dir=args.scratch, prefix="packed-scale-") as temp:
        directory = Path(temp)
        needed = 6 * max(args.sizes_mib, default=1) * MIB + 64 * MIB
        if shutil.disk_usage(directory).free < needed:
            raise SystemExit(f"test scratch needs {needed / MIB:.0f} MiB of free disk")
        exe = directory / "stream"
        subprocess.run(["c++", "-O3", "-std=c++17", str(HERE / "stream.cpp"), "-lgmpxx", "-lgmp",
                        "-o", exe], check=True)
        worker = ["prlimit", f"--as={96*MIB}", "--", str(exe)]
        model = next((line.split(":", 1)[1].strip() for line in
                      Path("/proc/cpuinfo").read_text().splitlines() if line.startswith("model name")), "")
        report = {"cpu": model, "logical_cpu": pinned, "system": platform.system(),
                  "machine": platform.machine(), "address_space_limit_mib": 96,
                  "gmp": subprocess.check_output(["pkg-config", "--modversion", "gmp"], text=True).strip(),
                  "cache": "source read before each timed sample; buffered output, no fsync",
                  "fixed_prime": str(MEMBER), "toy_cases": toy_checks(worker, directory), "cases": []}
        for size in case_sizes:
            checkpoint = args.checkpoint_row if size is None else None
            repeats = 1 if size and size >= 2048 else args.repeats
            print("30,000-prime checkpoint" if checkpoint else f"{size} MiB cofactor", flush=True)
            with tempfile.TemporaryDirectory(dir=directory) as work:
                report["cases"].append(run_case(worker, Path(work), size * MIB if size else None,
                                                checkpoint, repeats))
            args.output.write_text(json.dumps(report, indent=2) + "\n")


if __name__ == "__main__":
    main()
