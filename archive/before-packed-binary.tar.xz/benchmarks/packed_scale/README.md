# Packed arithmetic scale tests

## Test plan

Decide whether ordinary binary should replace packed nonadjacent form (NAF) for dense, positive access numbers. Keep the storage representation, the arithmetic kernel, and the workload separate when interpreting a timing.

| Case | Inputs | Checks decided before timing |
| --- | --- | --- |
| Boundaries and failure | Zero, one, long carries and borrows, both signs of NAF digits, partial bytes and arithmetic block boundaries | Compare both formats with an independent integer oracle. Reject inexact division and preserve any existing destination. |
| Actual prime product | Archived product of 30,000 distinct random 40-digit primes | Check the known member and outsider remainders. Remove the last prime and grant it back. Require identical original bytes in each format and the same binary quotient across formats. |
| File-backed dense scale | Deterministic dense cofactors of 8 MiB, 128 MiB and 1 GiB, each multiplied by the same 40-digit prime | Apply the same query, grant and revoke in both formats under a 96 MiB process address-space cap. Verify the restored cofactor and label byte for byte (streaming comparisons or SHA-256), and compare residues with an independent blockwise oracle. |
| Multi-gigabyte check | One additional 2 GiB dense cofactor under the same cap | Repeat all three operations and the same output checks. Report separately as a single trial. |
| Balanced multiplication | Two dense operands of comparable widths, rather than a growing label times one fixed-width ID | Check the complete product against an independent implementation. Time this separately from single-ID updates. |
| Sparse and structured controls | A sparse power tower and a repeated geometric series | Verify symbolic answers and sizes. Calculate the dense representation's size from its exponent before attempting allocation. |

Use identical operands and the same block arithmetic for the two file formats. Measure elapsed time reading an existing file and returning a remainder or publishing a completed output file. Record payload and record sizes, peak worker RSS, the address-space limit, repetitions and cache conditions. The OS file cache is separate from worker RAM. The synthetic large cases establish byte-scale behavior and carry propagation. Only the archived fixture establishes results on 30,000 actual prime IDs.

The [recorded short run](../results/packed-scale.json) covers the checkpoint, 8 MiB and 128 MiB. To reproduce it on Linux, install a C++17 compiler, GMP development libraries, pkg-config and util-linux. The checkpoint generator defines the ASCII signed `row` in the [storage report](../../docs/prime-access-storage-growth.md). Save those bytes as `30000.row`, then run:

```sh
python benchmarks/packed_scale/run.py --checkpoint-row 30000.row --sizes-mib 8 128 --output /tmp/packed-scale.json
```

Omit `--checkpoint-row` to run only the generated cases. All worker timings include file processing. The input is read immediately before timing and writes are buffered. Both lanes share the same GMP arithmetic and 64 KiB blocks.
