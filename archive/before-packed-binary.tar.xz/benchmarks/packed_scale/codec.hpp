// Streaming packed NAF benchmark codec. PNF1 stores a 4-byte tag, a
// little-endian uint64 NAF width and prefix tokens 0, 10, 11 (LSB first).
// Each nonzero token covers the digit and its compulsory following zero.
// This benchmark accepts unsigned magnitudes. A zero has an empty payload.
#pragma once

#include <algorithm>
#include <array>
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <limits>
#include <stdexcept>
#include <string>

namespace naf {
constexpr std::size_t buffer_size = 64 * 1024;

inline std::uint64_t load64(const unsigned char *p) {
    std::uint64_t x;
    std::memcpy(&x, p, sizeof(x));
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    x = __builtin_bswap64(x);
#endif
    return x;
}
inline void store64(unsigned char *p, std::uint64_t x) {
#if __BYTE_ORDER__ == __ORDER_BIG_ENDIAN__
    x = __builtin_bswap64(x);
#endif
    std::memcpy(p, &x, sizeof(x));
}
inline std::uint64_t payload_size(std::uint64_t width) {
    return width ? width / 8 + 1 : 0;
}
inline void write_bytes(std::ostream &out, const unsigned char *data, std::size_t size) {
    if (!out.write(reinterpret_cast<const char *>(data), size))
        throw std::runtime_error("packed codec write failed");
}
inline void write_header(std::ostream &out, std::uint64_t width) {
    unsigned char header[12] = {'P', 'N', 'F', '1'};
    store64(header + 4, width);
    write_bytes(out, header, sizeof(header));
}

class Encoder {
    std::string path_;
    std::ofstream out_;
    std::array<unsigned char, buffer_size> buffer_;
    std::uint64_t position_ = 0;
    std::uint64_t width_ = 0;
    unsigned carry_ = 0;

    template<unsigned Bits> std::uint64_t word(std::uint64_t binary) {
        // At position i the signed NAF digit equals bit(i+1,3N) - bit(i+1,N).
        // O = (3N XOR N) >> 1 marks nonzeros. P = O | ((3N XOR N) & N)
        // adds the sign of each negative digit in its following zero slot.
        // At the high boundary the next low bits differ iff our carry is odd.
        constexpr auto mask = UINT64_MAX >> (64 - Bits);
        const auto three = static_cast<unsigned __int128>(binary) * 3 + carry_;
        carry_ = static_cast<unsigned>(three >> Bits);
        const auto diff = (static_cast<std::uint64_t>(three) ^ binary) & mask;
        const auto occupied = (diff >> 1) |
                              (static_cast<std::uint64_t>(carry_ & 1) << (Bits - 1));
        if (occupied) width_ = position_ + (64 - __builtin_clzll(occupied));
        position_ += Bits;
        return occupied | (diff & binary);
    }

public:
    explicit Encoder(const std::string &path) : path_(path), out_(path, std::ios::binary) {
        write_header(out_, 0);
    }

    void write(const unsigned char *data, std::size_t size) {
        if (size > (UINT64_MAX - position_) / 8)
            throw std::runtime_error("PNF1 width overflow");
        while (size) {
            const std::size_t n = std::min(size, buffer_.size());
            std::size_t i = 0;
            for (; i + 8 <= n; i += 8)
                store64(buffer_.data() + i, word<64>(load64(data + i)));
            for (; i < n; ++i)
                buffer_[i] = static_cast<unsigned char>(word<8>(data[i]));
            write_bytes(out_, buffer_.data(), n);
            data += n;
            size -= n;
        }
    }

    void finish() {
        // Flush the carry into a zero extension, then drop all high padding
        // (a block-wise quotient can legitimately end in many zero bytes).
        const unsigned char zero = 0;
        write(&zero, 1);
        out_.seekp(0);
        write_header(out_, width_);
        out_.close();
        if (!out_) throw std::runtime_error("PNF1 final write failed");
        std::filesystem::resize_file(path_, 12 + payload_size(width_));
    }
};

struct Decoder {
    bool previous_occupied = false;
    int carry = 0;
    std::uint64_t position = 0, width = 0;

    template<unsigned Bits> std::uint64_t word(std::uint64_t packed) {
        // In each run of ones in P, alternating bits are digit markers;
        // the others are signs. Adding one at an even run start clears that
        // entire run. Markers there occupy even positions, and markers in
        // all remaining runs occupy odd positions. Preserve the phase across
        // words via the final marker in the previous word.
        constexpr std::uint64_t even = UINT64_C(0x5555555555555555);
        constexpr auto mask = UINT64_MAX >> (64 - Bits);
        const auto even_starts = packed & ~((packed << 1) | previous_occupied) & even;
        const auto even_runs = packed & ~(packed + even_starts);
        const auto occupied = (even_runs & even) | (packed & ~even_runs & ~even);
        previous_occupied = occupied >> (Bits - 1);
        if (occupied) width = position + (64 - __builtin_clzll(occupied));
        position += Bits;

        // If M is the mask of negative digits, P=O+2M and N=O-2M=2O-P.
        // Bias by one radix for defined unsigned arithmetic even on borrows.
        constexpr auto radix = static_cast<unsigned __int128>(1) << Bits;
        const auto value = radix + static_cast<unsigned __int128>(occupied) * 2 - packed + carry;
        carry = static_cast<int>(value >> Bits) - 1;
        return static_cast<std::uint64_t>(value) & mask;
    }
};

// Deliver minimal unsigned magnitude bytes to the callback, low-to-high.
template<class Consumer> void decode_blocks(const std::string &path, Consumer consume) {
    std::ifstream input(path, std::ios::binary);
    unsigned char header[12];
    if (!input.read(reinterpret_cast<char *>(header), sizeof(header)) ||
        std::memcmp(header, "PNF1", 4))
        throw std::runtime_error("invalid PNF1 header");
    const auto width = load64(header + 4);
    auto remaining = payload_size(width);
    if (std::filesystem::file_size(path) != 12 + remaining)
        throw std::runtime_error("invalid PNF1 payload length");
    if (remaining > UINT64_MAX / 8) throw std::runtime_error("PNF1 scan width overflow");

    Decoder decoder;
    std::array<unsigned char, buffer_size> buf;
    while (remaining) {
        std::size_t n = std::min<std::uint64_t>(remaining, buf.size());
        remaining -= n;
        if (!input.read(reinterpret_cast<char *>(buf.data()), n))
            throw std::runtime_error("truncated PNF1 payload");
        // For a positive number the sign of the last digit and all padding are zero.
        if (!remaining && (buf[n - 1] >> (width % 8)) != 0)
            throw std::runtime_error("invalid PNF1 sign or padding");
        std::size_t i = 0;
        for (; i + 8 <= n; i += 8)
            store64(buf.data() + i, decoder.word<64>(load64(buf.data() + i)));
        for (; i < n; ++i)
            buf[i] = static_cast<unsigned char>(decoder.word<8>(buf[i]));
        if (!remaining) {
            if (decoder.width != width || decoder.carry != 0 || decoder.previous_occupied)
                throw std::runtime_error("invalid PNF1 declared width");
            while (n && buf[n - 1] == 0) --n;
        }
        if (n) consume(buf.data(), n);
    }
}

inline void from_binary(const std::string &source, const std::string &destination) {
    std::ifstream input(source, std::ios::binary);
    if (!input) throw std::runtime_error("binary input open failed");
    Encoder encoder(destination);
    std::array<unsigned char, buffer_size> buf;
    while (input.read(reinterpret_cast<char *>(buf.data()), buf.size()) || input.gcount())
        encoder.write(buf.data(), static_cast<std::size_t>(input.gcount()));
    if (!input.eof() || input.bad()) throw std::runtime_error("binary input read failed");
    encoder.finish();
}

inline void to_binary(const std::string &source, const std::string &destination) {
    std::ofstream output(destination, std::ios::binary);
    decode_blocks(source, [&](const unsigned char *data, std::size_t size) {
        write_bytes(output, data, size);
    });
    output.close();
    if (!output) throw std::runtime_error("binary output write failed");
}
} // namespace naf
