"""Complement the file-backed single-prime tests with two different workloads.

1. A sparse tower must multiply and divide exactly and answer modulo queries
   without allocating its implied binary file. A regular series must pack
   to a geometric node and also work when the series denominator is noninvertible.
2. Two equally wide seeded random inputs must produce the Python reference
   product with both GMP limbs and the project's native signed-row multiplier.
   Time only the native kernels and returning their respective in-memory results.

Run with the native project extension, NumPy and gmpy2 installed.
"""

import json
import platform
from random import Random
from statistics import median
from time import perf_counter_ns

import gmpy2
import numpy as np

from symbolic_primes import Adaptive, Circuit, divide_fast, multiply_fast, residue
from symbolic_primes._accelerator import native

WIDTHS = (16_384, 1_048_576)
REPEATS = 5
SEED = 20261128
PRIME = 3589358312608496142804550037657486194871


def sparse_controls():
    c = Circuit()
    exponent = c.power(c.integer(80))
    x = c.power(exponent)
    minus, plus = c.subtract(x, c.one), c.add(x, c.one)
    value = multiply_fast(c, minus, plus)
    expected = c.subtract(c.power(c.add(exponent, exponent)), c.one)
    assert value is expected
    assert divide_fast(c, value, minus) is plus
    assert divide_fast(c, value, plus) is minus
    wire = c.encode(value)
    for modulus in (3, 97, 576, PRIME):
        expected_residue = (pow(2, 1 << 81, modulus) - 1) % modulus
        assert residue(c, wire, modulus, periods={PRIME: PRIME - 1}) == expected_residue

    # Apply an actual access ID to a sparse input; the new marking is still sparse.
    factor = c.integer(PRIME)
    granted = multiply_fast(c, plus, factor)
    assert divide_fast(c, granted, factor) is plus
    assert residue(c, c.encode(granted), PRIME, periods={PRIME: PRIME - 1}) == 0
    assert residue(c, plus, PRIME, periods={PRIME: PRIME - 1}) != 0

    n = ((1 << 1000) - 1) // 3
    adaptive = Adaptive(c)
    marking = c.integer(n)
    series = adaptive.pack(marking)
    assert series.kind == "geo"
    series_wire = adaptive.encode(series)
    restored = adaptive.decode(series_wire)
    for modulus in (3, 97, 576, PRIME):
        assert adaptive.residue(restored, modulus) == n % modulus
    return {
        "tower_product_h2n1_bytes": len(wire),
        "tower_product_binary_bytes_by_formula": (1 << 81) // 8,
        "sparse_prime_grant_h2n1_bytes": len(c.encode(granted)),
        "geometric_h2a1_bytes": len(series_wire),
        "geometric_binary_bytes": (n.bit_length() + 7) // 8,
        "geometric_canonical_terms": len(marking.terms),
    }


def signed_row(n):
    """Convert positive reference integers into canonical -1/0/+1 byte rows."""
    # At position i, the NAF digit is bit(i+1, 3n) minus bit(i+1, n).
    width = ((3 * n).bit_length() + 7) // 8

    def bits(value):
        data = np.frombuffer(value.to_bytes(width, "little"), dtype=np.uint8)
        return np.unpackbits(data, bitorder="little")

    return (bits((3 * n) >> 1) - bits(n >> 1)).tobytes().rstrip(b"\0")


def balanced_control(width):
    rng = Random(SEED + width)
    values = [rng.getrandbits(width) | (1 << (width - 1)) | 1 for _ in range(2)]
    x, y = values
    expected = x * y
    expected_row = signed_row(expected)
    left, right = map(signed_row, values)
    gx, gy = map(gmpy2.mpz, values)
    operations = [
        ("gmp_limbs", lambda: gx * gy),
        ("rust_signed_row", lambda: native.multiply_rows(left, right)),
    ]
    timings = {name: [] for name, _ in operations}
    for sample in range(REPEATS + 1):
        order = operations if sample % 2 == 0 else reversed(operations)
        for name, operation in order:
            start = perf_counter_ns()
            output = operation()
            elapsed = perf_counter_ns() - start
            if sample:
                timings[name].append(elapsed / 1_000_000)
            if name == "gmp_limbs":
                assert int(output) == expected
            else:
                assert output == expected_row
            del output
    return {
        "bits_per_operand": width,
        "product_bits": expected.bit_length(),
        "median_ms": {name: median(samples) for name, samples in timings.items()},
    }


if __name__ == "__main__":
    if native is None:
        raise SystemExit("Install the project with its Rust extension to run this benchmark.")
    print(json.dumps({
        "python": platform.python_version(),
        "gmp": gmpy2.mp_version(),
        "gmpy2": gmpy2.version(),
        "timed_calls_per_kernel": REPEATS,
        "sparse": sparse_controls(),
        "balanced": [balanced_control(width) for width in WIDTHS],
    }, indent=2))
