// File-backed benchmark for positive access labels. Format choice changes only
// the readers/writers in the paired lanes. GMP sees at most one block plus a prime.
#include "codec.hpp"
#include <gmpxx.h>
#include <sys/resource.h>
#include <unistd.h>

#include <algorithm>
#include <array>
#include <chrono>
#include <cstdio>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;
using Byte = unsigned char;
constexpr std::size_t BLOCK = 64 * 1024;

class TemporaryOutput {
    std::string path_;
public:
    explicit TemporaryOutput(const std::string& destination) : path_(destination + ".tmp.XXXXXX") {
        int fd = mkstemp(path_.data());
        if (fd < 0) throw std::runtime_error("cannot create temporary output beside " + destination);
        if (close(fd) != 0) {
            std::remove(path_.c_str());
            throw std::runtime_error("cannot close temporary output");
        }
    }
    TemporaryOutput(const TemporaryOutput&) = delete;
    ~TemporaryOutput() { if (!path_.empty()) std::remove(path_.c_str()); }
    const std::string& path() const { return path_; }
    void publish(const std::string& destination) {
        fs::rename(path_, destination);
        path_.clear();
    }
};

class Output {
    fs::path path_;
    std::ofstream binary_;
    std::unique_ptr<naf::Encoder> naf_;
    std::uintmax_t length_ = 0, significant_ = 0;
public:
    Output(const std::string& path, bool use_naf) : path_(path) {
        if (use_naf) naf_ = std::make_unique<naf::Encoder>(path);
        else {
            binary_.exceptions(std::ios::badbit | std::ios::failbit);
            binary_.open(path, std::ios::binary | std::ios::trunc);
        }
    }
    void write(const Byte* data, std::size_t n) {
        if (!n) return;
        if (naf_) { naf_->write(data, n); return; }
        auto used = n;
        while (used && data[used - 1] == 0) --used;
        if (used) significant_ = length_ + used;
        binary_.write(reinterpret_cast<const char*>(data), n);
        length_ += n;
    }
    void finish() {
        if (naf_) { naf_->finish(); return; }
        binary_.close();
        if (length_ != significant_) fs::resize_file(path_, significant_);
    }
};

template<class Consumer>
void read_binary(const std::string& path, Consumer consume) {
    std::ifstream in(path, std::ios::binary);
    if (!in) throw std::runtime_error("cannot open input " + path);
    std::array<Byte, BLOCK> buf;
    bool any = false;
    Byte last = 0;
    while (in.read(reinterpret_cast<char*>(buf.data()), buf.size()) || in.gcount()) {
        std::size_t n = in.gcount();
        any = true;
        last = buf[n-1];
        consume(buf.data(), n);
    }
    if (in.bad() || !in.eof()) throw std::runtime_error("binary input read failure");
    if (any && !last) throw std::runtime_error("noncanonical binary high zero");
}

// Normalize a codec's output chunk boundaries for the arithmetic comparison.
template<class Consumer>
void read_blocks(bool use_naf, const std::string& path, Consumer consume) {
    if (!use_naf) { read_binary(path, consume); return; }
    std::array<Byte, BLOCK> pending;
    std::size_t used = 0;
    naf::decode_blocks(path, [&](const Byte* data, std::size_t n) {
        while (n) {
            if (!used && n >= BLOCK) {
                consume(data, BLOCK);
                data += BLOCK;
                n -= BLOCK;
                continue;
            }
            auto take = std::min(BLOCK-used, n);
            std::copy_n(data, take, pending.data()+used);
            data += take;
            n -= take;
            used += take;
            if (used == BLOCK) { consume(pending.data(), used); used = 0; }
        }
    });
    if (used) consume(pending.data(), used);
}

void import_le(mpz_class& value, const Byte* data, std::size_t n) {
    mpz_import(value.get_mpz_t(), n, -1, 1, 0, 0, data);
}

std::size_t export_le(const mpz_class& value, Byte* data, std::size_t n) {
    if (value < 0 || (value != 0 && mpz_sizeinbase(value.get_mpz_t(), 2) > n*8))
        throw std::logic_error("arithmetic output exceeds its block");
    std::size_t used;
    mpz_export(data, &used, -1, 1, 0, 0, value.get_mpz_t());
    std::fill(data+used, data+n, Byte(0));
    return used;
}

enum class Operation { Mod, Mul, Div };

struct Answer { bool exact = true; mpz_class remainder = 0; };

Answer ascending(bool use_naf, Operation op, const std::string& input,
                 const mpz_class& p, Output* out) {
    Answer result;
    mpz_class u, carry, next, value, scale = 1, radix, inverse;
    std::size_t radix_width = 0;
    std::array<Byte, BLOCK> bytes;
    bool first = true;
    Byte deferred = 0;
    read_blocks(use_naf, input, [&](const Byte* data, std::size_t n) {
        if (op == Operation::Div && p == 2) {
            if (first) { result.exact = (data[0]&1) == 0; first = false; }
            else {
                Byte prior = (deferred >> 1) | ((data[0]&1) << 7);
                out->write(&prior, 1);
            }
            for (std::size_t i=0; i+1<n; ++i)
                bytes[i] = (data[i] >> 1) | ((data[i+1]&1) << 7);
            out->write(bytes.data(), n-1);
            deferred = data[n-1];
            return;
        }
        auto bits = static_cast<mp_bitcnt_t>(8*n);
        if (op != Operation::Mul && n != radix_width) {
            mpz_set_ui(radix.get_mpz_t(), 0);
            mpz_setbit(radix.get_mpz_t(), bits);
            mpz_mod(radix.get_mpz_t(), radix.get_mpz_t(), p.get_mpz_t());
            if (op == Operation::Div &&
                !mpz_invert(inverse.get_mpz_t(), radix.get_mpz_t(), p.get_mpz_t()))
                throw std::runtime_error("ascending division needs an odd divisor or 2");
            radix_width = n;
        }
        import_le(u, data, n);
        if (op == Operation::Mod) {
            // u is one block. Fold u * 2^(bits already read) modulo p.
            mpz_mod(u.get_mpz_t(), u.get_mpz_t(), p.get_mpz_t());
            result.remainder = (result.remainder + u*scale) % p;
            scale = (scale*radix) % p;
        } else if (op == Operation::Mul) {
            value = u*p + carry;
            mpz_fdiv_q_2exp(carry.get_mpz_t(), value.get_mpz_t(), bits);
            mpz_fdiv_r_2exp(value.get_mpz_t(), value.get_mpz_t(), bits);
            export_le(value, bytes.data(), n);
            out->write(bytes.data(), n);
        } else {
            // For radix R=2^bits solve carry+p*q = u+R*next.
            // Picking next in [0,p) determines q in [0,R); a nonzero final
            // carry proves that the candidate quotient extends past the input.
            value = u-carry;
            mpz_mod(next.get_mpz_t(), value.get_mpz_t(), p.get_mpz_t());
            next = (p-next)*inverse % p;
            value += next << bits;
            mpz_divexact(value.get_mpz_t(), value.get_mpz_t(), p.get_mpz_t());
            carry.swap(next);
            export_le(value, bytes.data(), n);
            out->write(bytes.data(), n);
        }
    });
    if (op == Operation::Div && p == 2 && !first) {
        Byte last = deferred >> 1;
        out->write(&last, 1);
    }
    if (op == Operation::Mul && carry != 0) {
        std::vector<Byte> tail((mpz_sizeinbase(carry.get_mpz_t(),2)+7)/8);
        export_le(carry, tail.data(), tail.size());
        out->write(tail.data(), tail.size());
    }
    result.exact = result.exact && (op != Operation::Div || carry == 0);
    return result;
}

// Conventional binary-only control. Each block includes any remainder from
// higher positions; quotient blocks can be written directly at their offsets.
Answer descending(Operation op, const std::string& path, const mpz_class& p,
                  const std::string& output) {
    std::ifstream in(path, std::ios::binary);
    in.exceptions(std::ios::badbit | std::ios::failbit);
    std::ofstream out;
    if (op == Operation::Div) {
        out.exceptions(std::ios::badbit | std::ios::failbit);
        out.open(output, std::ios::binary | std::ios::trunc);
    }
    std::array<Byte,BLOCK> bytes;
    mpz_class rem, block, q;
    std::uintmax_t end = fs::file_size(path);
    bool top = true, emitted = false;
    while (end) {
        std::size_t n = (end-1)%BLOCK + 1;
        auto offset = end-n;
        in.seekg(offset);
        in.read(reinterpret_cast<char*>(bytes.data()), n);
        if (top && !bytes[n-1]) throw std::runtime_error("noncanonical binary high zero");
        top = false;
        import_le(block, bytes.data(), n);
        block += rem << (8*n);
        if (op == Operation::Mod)
            mpz_mod(rem.get_mpz_t(), block.get_mpz_t(), p.get_mpz_t());
        else {
            mpz_tdiv_qr(q.get_mpz_t(), rem.get_mpz_t(), block.get_mpz_t(), p.get_mpz_t());
            auto used = export_le(q, bytes.data(), n);
            std::size_t to_write = emitted ? n : used;
            if (to_write) {
                emitted = true;
                out.seekp(offset);
                out.write(reinterpret_cast<const char*>(bytes.data()), to_write);
            }
        }
        end = offset;
    }
    if (op == Operation::Div) out.close();
    return {op == Operation::Mod || rem == 0, rem};
}

int run(int argc, char** argv) {
    if (argc < 3) throw std::runtime_error("expected lane and operation");
    std::string lane = argv[1], name = argv[2];
    if (lane == "convert") {
        if (argc != 5) throw std::runtime_error("convert MODE INPUT OUTPUT");
        TemporaryOutput tmp(argv[4]);
        if (name == "bin-to-naf") naf::from_binary(argv[3], tmp.path());
        else if (name == "naf-to-bin") naf::to_binary(argv[3], tmp.path());
        else throw std::runtime_error("unknown conversion");
        tmp.publish(argv[4]);
        return 0;
    }
    if (lane != "binary" && lane != "naf" && lane != "binary-msb")
        throw std::runtime_error("lane must be binary, naf or binary-msb");
    if (name != "mod" && name != "mul" && name != "div")
        throw std::runtime_error("operation must be mod, mul or div");
    Operation op = name == "mod" ? Operation::Mod : name == "mul" ? Operation::Mul : Operation::Div;
    if (argc != (op == Operation::Mod ? 5 : 6))
        throw std::runtime_error("expected INPUT DECIMAL_PRIME [OUTPUT]");
    mpz_class p(argv[4], 10);
    if (p < 2) throw std::runtime_error("prime must be at least 2");
    std::unique_ptr<TemporaryOutput> tmp;
    if (op != Operation::Mod) tmp = std::make_unique<TemporaryOutput>(argv[5]);
    Answer answer;
    if (lane == "binary-msb" && op != Operation::Mul)
        answer = descending(op, argv[3], p, tmp ? tmp->path() : "");
    else {
        std::unique_ptr<Output> writer;
        if (tmp) writer = std::make_unique<Output>(tmp->path(), lane == "naf");
        answer = ascending(lane == "naf", op, argv[3], p, writer.get());
        if (writer && answer.exact) writer->finish();
    }
    if (!answer.exact) return 3;
    if (op == Operation::Mod) std::cout << answer.remainder << '\n';
    if (tmp) tmp->publish(argv[5]);
    return 0;
}

int main(int argc, char** argv) {
    auto start = std::chrono::steady_clock::now();
    try {
        int status = run(argc,argv);
        std::chrono::duration<double> elapsed = std::chrono::steady_clock::now()-start;
        rusage usage{};
        if (getrusage(RUSAGE_SELF,&usage) != 0) throw std::runtime_error("getrusage failure");
        std::cerr << std::fixed << std::setprecision(8) << "seconds=" << elapsed.count()
                  << " peak_rss_kib=" << usage.ru_maxrss << '\n';
        return status;
    } catch (const std::exception& e) {
        std::cerr << e.what() << '\n';
        return 1;
    }
}
